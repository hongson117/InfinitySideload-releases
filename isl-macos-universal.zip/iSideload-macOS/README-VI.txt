∞Sideload macOS — CÀI APP & TỰ THIẾT LẬP GHÉP ĐÔI / macOS USB INSTALLER & PAIRING
Gói Universal: Mac Apple Silicon + Intel, macOS 11+. iPhone/iPad cần iOS/iPadOS 17.4+.

================================================================================
🇻🇳 HƯỚNG DẪN TIẾNG VIỆT
================================================================================

CHUẨN BỊ
1. Giải nén toàn bộ ZIP vào một thư mục, giữ các file cạnh nhau.
2. Cắm iPhone bằng cáp dữ liệu, mở khóa, mở Finder và chọn thiết bị trong thanh bên.
3. Bấm Trust/Tin cậy trên Mac và trên iPhone, nhập mật mã iPhone nếu được hỏi.
4. Chuẩn bị Apple ID sẽ dùng để ký/gia hạn và thiết bị nhận mã 2FA.

CHẾ ĐỘ [1] — CÀI TỪ ĐẦU (TIẾNG VIỆT)
1. Nhấp đúp Cai-iSideload.command để mở Terminal, chọn 1.
2. Nhập Apple ID, mật khẩu (ẩn khi gõ), mã 2FA nếu được hỏi.
3. Công cụ ký và cài ∞Sideload. Nếu Chế độ nhà phát triển chưa bật, vào Cài đặt > Quyền riêng tư & Bảo mật > Chế độ nhà phát triển > Bật, khởi động lại rồi nhấn Enter trên Mac.
4. Giữ iPhone mở khóa, đóng hẳn ∞Sideload trong khi công cụ tạo và chép file Remote Pairing vào app.
5. Tin cậy chứng chỉ tại Cài đặt > Cài đặt chung > VPN & Quản lý thiết bị, bật LocalDevVPN/StosVPN và mở ∞Sideload.

CHẾ ĐỘ [2] — ĐÃ CÓ ∞SIDELOAD, CHỈ SỬA GHÉP ĐÔI (TIẾNG VIỆT)
1. Cắm iPhone, mở khóa, đóng hẳn ∞Sideload.
2. Mở Cai-iSideload.command, chọn 2.

================================================================================
🇬🇧 ENGLISH GUIDE
================================================================================

PREPARATION
1. Extract the entire ZIP archive into a folder, keeping all files together.
2. Connect your iPhone via USB data cable, unlock it, open Finder, and select the device in the sidebar.
3. Click Trust on your Mac and tap Trust on your iPhone, then enter your iPhone passcode.
4. Have your Apple ID and 2FA code ready.

MODE [3] — FRESH INSTALL (ENGLISH)
1. Double-click Cai-iSideload.command to open Terminal and enter 3.
2. Enter your Apple ID, password (hidden while typing), and 2FA code if prompted.
3. The tool signs and installs ∞Sideload. If Developer Mode is off, go to Settings > Privacy & Security > Developer Mode > Turn On, restart your iPhone, tap Turn On, and press Enter on your Mac.
4. Keep your iPhone unlocked and fully close ∞Sideload while the tool creates, verifies, and uploads the Remote Pairing file into the app.
5. Trust your developer certificate in Settings > General > VPN & Device Management, enable LocalDevVPN/StosVPN, and open ∞Sideload (tap VI/EN in the top-left corner or Settings to switch language).

MODE [4] — REPAIR PAIRING ONLY (ENGLISH)
1. Connect your iPhone via USB, unlock it, and completely close ∞Sideload.
2. Open Cai-iSideload.command and enter 4 (no Apple ID login required).

IF GATEKEEPER BLOCKS THE BINARY
Open System Settings > Privacy & Security > Open Anyway for Cai-iSideload.command and isl-mac.

CLI USAGE
  ./isl-mac --lang en ./SIContainer.ipa
  ./isl-mac --lang en --pair-only
  ./isl-mac --lang en --list-devices
  ./isl-mac --lang en --self-test
