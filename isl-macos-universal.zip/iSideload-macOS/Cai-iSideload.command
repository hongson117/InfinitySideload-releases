#!/bin/bash
set -uo pipefail
cd -- "$(dirname -- "$0")" || exit 1
printf '\n=== ∞SIDELOAD — CÀI APP & GHÉP ĐÔI USB / macOS USB INSTALLER ===\n\n'
printf '[VI] 1. Cắm iPhone/iPad bằng cáp dữ liệu, mở khóa.\n'
printf '     2. Mở Finder, chọn thiết bị; xác nhận Trust/Tin cậy trên cả hai máy.\n'
printf '     3. Chuẩn bị Apple ID sẽ dùng để ký/gia hạn và mã 2FA.\n'
printf '[EN] 1. Connect iPhone/iPad via USB data cable and unlock it.\n'
printf '     2. Open Finder, select the device, and confirm Trust on both Mac and iPhone.\n'
printf '     3. Have your Apple ID and 2FA code ready.\n\n'
IPA_FILE="./SIContainer.ipa"
if [[ ! -f "$IPA_FILE" ]]; then
  IPA_FILE="./iSideload.ipa"
fi
if [[ ! -x ./isl-mac || ! -f "$IPA_FILE" ]]; then
  printf '\nThiếu công cụ hoặc IPA. Hãy giải nén đầy đủ isl-macos-universal.zip.\n'
  printf 'Missing binary or IPA. Please extract the full isl-macos-universal.zip archive.\n'
  read -r -p 'Nhấn Enter để đóng / Press Enter to close… ' _
  exit 2
fi
if ! /usr/bin/shasum -a 256 -c SHA256SUMS.txt; then
  printf '\nChecksum không khớp. Chưa chạy công cụ; hãy tải lại gói từ trang phát hành chính thức.\n'
  printf 'Checksum mismatch. Tool was not started; please re-download from the official release page.\n'
  read -r -p 'Nhấn Enter để đóng / Press Enter to close… ' _
  exit 2
fi
printf '\n[1] (Tiếng Việt) Cài từ đầu: ký, cài ∞Sideload và tự thiết lập file ghép đôi\n'
printf '[2] (Tiếng Việt) Đã có ∞Sideload: chỉ thiết lập hoặc sửa ghép đôi\n'
printf '[3] (English)    Fresh Install: sign, install ∞Sideload & set up Remote Pairing\n'
printf '[4] (English)    Repair Pairing Only: set up or repair pairing for installed app\n\n'
read -r -p 'Chọn 1/2/3/4 (Enter để hủy / Press Enter to cancel): ' mode || exit 1
case "$mode" in
  1) ./isl-mac "$IPA_FILE" ;;
  2) ./isl-mac --pair-only ;;
  3) ./isl-mac --lang en "$IPA_FILE" ;;
  4) ./isl-mac --lang en --pair-only ;;
  *) printf '\nĐã hủy. Chưa bắt đầu cài hay thiết lập ghép đôi. / Cancelled.\n'; exit 1 ;;
esac
result=$?
if [[ $result -ne 0 ]]; then
  if [[ "$mode" == "3" || "$mode" == "4" ]]; then
    printf '\nTool exited with code %s. Check the error above and README-VI.txt.\n' "$result"
    printf 'If macOS Gatekeeper blocked an unnotarized binary: open System Settings > Privacy & Security > Open Anyway.\n'
  else
    printf '\nCông cụ kết thúc với mã %s. Xem lỗi ở trên và README-VI.txt.\n' "$result"
    printf 'Nếu macOS chặn công cụ chưa notarize: dùng System Settings > Privacy & Security > Open Anyway cho đúng file này.\n'
  fi
fi
read -r -p 'Nhấn Enter để đóng cửa sổ / Press Enter to close… ' _
exit "$result"
