@echo off
chcp 65001 >nul
setlocal
title ∞Sideload — Cài app & ghép đôi USB / USB Installer & Pairing
cd /d "%~dp0"
echo =====================================================================
echo   ∞SIDELOAD — CÀI APP ^& GHÉP ĐÔI QUA USB / USB INSTALLER ^& PAIRING
echo =====================================================================
echo Đang kiểm tra bộ cài... / Verifying installer package...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Kiem-tra-goi.ps1"
if errorlevel 1 (
  echo Bộ cài thiếu file hoặc bị thay đổi. Tải lại và giải nén toàn bộ ZIP.
  echo Package is missing files or modified. Please re-download and extract the full ZIP.
  pause
  exit /b 2
)
echo.
echo [VI] Cắm iPhone bằng cáp dữ liệu, mở khóa và bấm Tin cậy máy tính.
echo      Cần cài Apple Devices hoặc iTunes và bật Chế độ nhà phát triển.
echo [EN] Connect iPhone via USB data cable, unlock it, and tap Trust This Computer.
echo      Requires Apple Devices or iTunes installed and Developer Mode enabled.
echo.
echo [1] (Tiếng Việt) Cài từ đầu: ký, cài ∞Sideload và tự thiết lập file ghép đôi
echo [2] (Tiếng Việt) Đã có ∞Sideload: chỉ thiết lập hoặc sửa file ghép đôi
echo [3] (English)    Fresh Install: sign, install ∞Sideload ^& set up Remote Pairing
echo [4] (English)    Repair Pairing Only: set up or repair pairing for installed app
echo.
choice /C 1234 /N /M "Chọn / Select [1/2/3/4]: "
if errorlevel 5 goto cancelled
if not errorlevel 1 goto cancelled
if errorlevel 4 (
  "%~dp0isl-cli.exe" --lang en --pair-only
  goto finished_en
)
if errorlevel 3 (
  if exist "%~dp0SIContainer.ipa" (
    "%~dp0isl-cli.exe" --lang en "%~dp0SIContainer.ipa"
  ) else (
    "%~dp0isl-cli.exe" --lang en "%~dp0iSideload.ipa"
  )
  goto finished_en
)
if errorlevel 2 (
  "%~dp0isl-cli.exe" --pair-only
  goto finished_vi
)
if exist "%~dp0SIContainer.ipa" (
  "%~dp0isl-cli.exe" "%~dp0SIContainer.ipa"
) else (
  "%~dp0isl-cli.exe" "%~dp0iSideload.ipa"
)
:finished_vi
set "ISL_RESULT=%ERRORLEVEL%"
echo.
if not "%ISL_RESULT%"=="0" echo Chưa hoàn tất. Đọc dòng lỗi phía trên; app đã cài có thể tiếp tục bằng chế độ 2.
pause
exit /b %ISL_RESULT%
:finished_en
set "ISL_RESULT=%ERRORLEVEL%"
echo.
if not "%ISL_RESULT%"=="0" echo Not completed. Check the error message above; if the app is already installed, you can resume with mode 4.
pause
exit /b %ISL_RESULT%
:cancelled
echo Đã hủy / Cancelled.
exit /b 1
