# ∞Sideload (SIContainer) Windows — Cài từ đầu & thiết lập ghép đôi / First-Time USB Installer & Pairing

Bộ cài Windows hỗ trợ **Tiếng Việt** (`[1]`, `[2]`) và **English** (`[3]`, `[4]`): ký, cài **∞Sideload** kèm tự động tạo & chép file Remote Pairing qua cáp USB, hoặc chỉ sửa ghép đôi cho app đã cài sẵn. Hỗ trợ Windows 10/11 x64 và iPhone/iPad chạy iOS/iPadOS 17.4 trở lên.

---

## 🇻🇳 Hướng dẫn Tiếng Việt

### Chuẩn bị
1. Cài **Apple Devices** từ Microsoft Store hoặc **iTunes** từ Apple để có driver USB và dịch vụ `Apple Mobile Device Service`.
2. Cắm iPhone bằng cáp dữ liệu, mở khóa, bấm **Tin cậy máy tính này** và nhập mật mã trên iPhone.
3. Giải nén toàn bộ file ZIP (`Extract All / Giải nén tất cả`) ra một thư mục riêng. Không chạy trực tiếp bên trong cửa sổ xem trước ZIP.

### Chế độ `[1]` — Cài từ đầu (Ký, cài ∞Sideload & tự thiết lập Remote Pairing)
1. Mở **`Cai-iSideload.bat`**, chọn **`1`**.
2. Nhập Apple ID, mật khẩu (được ẩn khi gõ) và mã 2FA nếu được yêu cầu.
3. Công cụ tự động ký và cài **∞Sideload** vào iPhone qua USB.
4. Nếu Chế độ nhà phát triển chưa bật, vào **Cài đặt → Quyền riêng tư & Bảo mật → Chế độ nhà phát triển**, bật lên, khởi động lại máy rồi nhấn Enter trên máy tính.
5. Giữ iPhone mở khóa và đóng hẳn ∞Sideload trong lúc công cụ tạo & chép file Remote Pairing.
6. Trên iPhone, tin cậy chứng chỉ tại **Cài đặt → Cài đặt chung → VPN & Quản lý thiết bị**.
7. Cài **LocalDevVPN** hoặc **StosVPN** từ App Store, bật VPN và mở **∞Sideload** để cài thêm Runner 1 / Runner 2 và sử dụng hoàn toàn trên điện thoại.

### Chế độ `[2]` — Đã có ∞Sideload, chỉ thiết lập hoặc sửa file ghép đôi
1. Cắm iPhone qua USB, mở khóa và đóng hẳn ∞Sideload.
2. Mở **`Cai-iSideload.bat`**, chọn **`2`** (không cần nhập lại Apple ID).

---

## 🇬🇧 English Guide

### Preparation
1. Install **Apple Devices** from the Microsoft Store or **iTunes** from Apple so Windows has the USB driver and `Apple Mobile Device Service`.
2. Connect your iPhone via a USB data cable, unlock the screen, tap **Trust This Computer**, and enter your passcode.
3. Extract the entire ZIP archive (`Extract All`) into a regular folder. Do not run `Cai-iSideload.bat` directly from inside the ZIP preview window.

### Mode `[3]` — Fresh Install (Sign, install ∞Sideload & set up Remote Pairing)
1. Double-click **`Cai-iSideload.bat`** and press **`3`**.
2. Enter your Apple ID, password (hidden while typing), and 2FA code if prompted.
3. The tool signs and installs **∞Sideload** over USB.
4. If Developer Mode is off, open **Settings → Privacy & Security → Developer Mode** on your iPhone, turn it on, restart, tap Turn On, and press Enter on your PC.
5. Keep your iPhone unlocked and fully close ∞Sideload while the tool generates, verifies, and uploads the Remote Pairing file into the app.
6. Trust your developer certificate on iPhone under **Settings → General → VPN & Device Management**.
7. Install **LocalDevVPN** or **StosVPN** from the App Store, connect the VPN, and open **∞Sideload** (you can switch the app language between `VI` and `EN` in the top-left corner or in Settings).

### Mode `[4]` — Repair Pairing Only (App already installed)
1. Connect your iPhone via USB, unlock it, and completely close ∞Sideload.
2. Double-click **`Cai-iSideload.bat`** and press **`4`** (no Apple ID login required).

---

## Dòng lệnh / Command-Line Usage
- `isl-cli.exe SIContainer.ipa` (Tiếng Việt) / `isl-cli.exe --lang en SIContainer.ipa` (English)
- `isl-cli.exe --pair-only` (Tiếng Việt) / `isl-cli.exe --lang en --pair-only` (English)
- `isl-cli.exe --list-devices` / `isl-cli.exe --lang en --list-devices`
- `isl-cli.exe --self-test` / `isl-cli.exe --lang en --self-test`
